##
## This script is sourced by /data/data/com.agy/files/usr/bin/login before executing shell.
##
