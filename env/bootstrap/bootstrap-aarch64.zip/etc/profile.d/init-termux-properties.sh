if [ ! -f /data/data/com.agy/files/home/.config/termux/termux.properties ] && [ ! -e /data/data/com.agy/files/home/.termux/termux.properties ]; then
	mkdir -p /data/data/com.agy/files/home/.termux
	cp /data/data/com.agy/files/usr/share/examples/termux/termux.properties /data/data/com.agy/files/home/.termux/
fi
